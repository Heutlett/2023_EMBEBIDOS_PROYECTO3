#include <unistd.h> /* usleep */
#include <gpio_rpi.h>
#include <stdio.h>

int main()
{
    gpio_rpi_init_ptrs();

    // Configurar todos los pines como output
    gpio_rpi_set_mode_all(1);
    // Verificar modo
    gpio_rpi_get_mode_all();

    // Poner todos los pines en 1
    gpio_rpi_write_all(1);
    gpio_rpi_read(7); // ver estado pin 7

    usleep(1000000);
    // Poner todos los pines en 0
    gpio_rpi_write_all(0);
    gpio_rpi_read(7); // ver estado pin 7

    usleep(1000000);

    // Poner 1 a pin 5
    gpio_rpi_write(1, 5);
    gpio_rpi_read(5);
    
    usleep(1000000);
    return 0;
}
